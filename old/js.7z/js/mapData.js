/**
 * マップデータ
 */
let cMapData = function(point) {
	this.cube;
	this.position;
	this.point;

	this.init(point);
};

cMapData.prototype.init = function(point) {
	this.cube = null;
	this.position = point;
	this.point = new cPoint(0, 0, 0);
	this.resetPoint();
};

cMapData.prototype.resetPoint = function() {
	let x = this.position.getX() * 16;
	x += this.position.getZ() * 16
	x += Math.floor(15 * MAP_Z_MAX);
	this.point.setX(x);

	let y = this.position.getY() * 16;
	y += this.position.getX() * 8;
	y -= this.position.getZ() * 8;
	y += 96;
	this.point.setY(y);

	let z = this.position.getZ() * 32;
	this.point.setZ(z);
};

cMapData.prototype.createCube = function() {
	this.cube = new cCube(this.point);
	this.hidden();
};

cMapData.prototype.getCubeSprite = function() {
	return this.cube.getSprite();
};

cMapData.prototype.hidden = function() {
	this.cube.getSprite().visible = false;
};

cMapData.prototype.show = function() {
	this.cube.getSprite().visible = true;
};