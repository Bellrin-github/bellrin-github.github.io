/**
 * マップ
 */
cMap = function() {
	this.point;
	this.map;

	this.init();
};
inherits(cMap, cTask);

cMap.prototype.init = function() {
	this.point = new cPoint(0, 0, WINDOW_SIZE_W, WINDOW_SIZE_H);
	this.getGroup().x = this.point.x;
	this.getGroup().y = this.point.y;

	this.map = new Array(MAP_Z_MAX);
	for (let z = MAP_Z_MAX-1; z >= 0 ; --z) {
		this.map[z] = new Array(MAP_Y_MAX);
		for (let y = MAP_Y_MAX-1; y >= 0 ; --y) {
			this.map[z][y] = new Array(MAP_X_MAX);
			for (let x = 0; x < MAP_X_MAX; ++x) {
				this.map[z][y][x] = new cMapData(new cPoint(x, y, z));
				this.map[z][y][x].createCube();
				if (testMapData[z][y][x]) {
					this.map[z][y][x].show();
				}
				this.getGroup().addChild(this.map[z][y][x].getCubeSprite());
			}
		}
	}
};

cMap.prototype.action = function() {

	return true;
};

cMap.prototype.draw = function() {

};
