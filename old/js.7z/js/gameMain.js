cGameMain = function() {
	this.scene;
	this.map;
};
inherits(cGameMain, cTask);

cGameMain.prototype.init = function() {
	this.task = GAME_MAIN_TASK_ACTION;
	this.scene = new Scene();
    this.scene.backgroundColor = "white";
	this.scene.addChild(this.getGroup());
	this.scene.addEventListener('enterframe', () => {
		this.action();
		this.draw();
	});

	this.map;
	this.map = new cMap();
	this.getGroup().addChild(this.map.getGroup());
};

cGameMain.prototype.action = function() {
	switch (this.task) {
		case GAME_MAIN_TASK_ACTION:
			
			break;
	}

	return true;
};

cGameMain.prototype.draw = function() {
	switch (this.task) {
		case GAME_MAIN_TASK_ACTION:
			
			break;
		case GAME_MAIN_TASK_GAMEOVER:
			break;
	}
};

cGameMain.prototype.getScene = function() {
	return this.scene;
};
