/**
 * 座標
 */
let cPoint = function(x, y, z) {
	this.x;
	this.y;
	this.z;

	this.init(x, y, z);
};

cPoint.prototype.init = function(x, y, z) {
	this.x = x?x:0;
	this.y = y?y:0;
	this.z = z?z:0;
};

cPoint.prototype.getX = function() {
	return this.x
};

cPoint.prototype.setX = function(x) {
	this.x = Math.floor(x);
};

cPoint.prototype.getY = function() {
	return this.y;
};

cPoint.prototype.setY = function(y) {
	this.y = Math.floor(y);
};

cPoint.prototype.getZ = function() {
	return this.z;
};

cPoint.prototype.setZ = function(z) {
	this.z = Math.floor(z);
};
