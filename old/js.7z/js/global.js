// [z][y][x]
let map;

let testMapData;
testMapData = new Array(MAP_Z_MAX);
for (let z = MAP_Z_MAX-1; z >= 0 ; --z) {
	testMapData[z] = new Array(MAP_Y_MAX);
	for (let y = MAP_Y_MAX-1; y >= 0 ; --y) {
		testMapData[z][y] = new Array(MAP_X_MAX);
		for (let x = 0; x < MAP_X_MAX; ++x) {
			testMapData[z][y][x] = false;
		}
	}
}

testMapData[2][MAP_Y_MAX - 1][0] = true;
testMapData[2][MAP_Y_MAX - 1][1] = true;
testMapData[2][MAP_Y_MAX - 1][2] = true;
testMapData[2][MAP_Y_MAX - 1][3] = true;
testMapData[2][MAP_Y_MAX - 1][4] = true;
testMapData[2][MAP_Y_MAX - 1][5] = true;
testMapData[2][MAP_Y_MAX - 1][6] = true;

testMapData[3][MAP_Y_MAX - 2][0] = true;
testMapData[3][MAP_Y_MAX - 2][1] = true;
testMapData[3][MAP_Y_MAX - 2][2] = true;
testMapData[3][MAP_Y_MAX - 2][3] = true;
testMapData[3][MAP_Y_MAX - 2][4] = true;
testMapData[3][MAP_Y_MAX - 2][5] = true;
testMapData[3][MAP_Y_MAX - 2][6] = true;

testMapData[3][MAP_Y_MAX - 3][0] = true;
testMapData[3][MAP_Y_MAX - 3][1] = true;
testMapData[3][MAP_Y_MAX - 3][2] = true;
testMapData[3][MAP_Y_MAX - 3][3] = true;
testMapData[3][MAP_Y_MAX - 3][4] = true;
testMapData[3][MAP_Y_MAX - 3][5] = true;
testMapData[3][MAP_Y_MAX - 3][6] = true;

testMapData[3][MAP_Y_MAX - 4][0] = true;
testMapData[3][MAP_Y_MAX - 4][1] = true;
testMapData[3][MAP_Y_MAX - 4][2] = true;
testMapData[3][MAP_Y_MAX - 4][3] = true;
testMapData[3][MAP_Y_MAX - 4][4] = true;
testMapData[3][MAP_Y_MAX - 4][5] = true;
testMapData[3][MAP_Y_MAX - 4][6] = true;