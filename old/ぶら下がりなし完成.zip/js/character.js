/**
 * キャラクター
 */
cCharacter = function(x, y, z) {
	this.position;
	this.point;
	this.sprite;
	this.status;
	this.direction; // 向き

	this.init(x, y, z);
};
inherits(cCharacter, cTask);

cCharacter.prototype.init = function(x, y, z) {
	this.direction = D_RIGHT;

	this.sprite = new Sprite(32, 32);
	this.sprite.image = game.assets[IMG_CHARACTER];
	this.sprite.x = 0;
	this.sprite.y = 0;
	this.sprite.frame = this.direction;

	this.status = CHARACTER_STATUS_NORMAL;

	this.getGroup().addChild(this.sprite);

	this.position = new cPoint(x, y, z);
	this.point = positionToPoint(this.position);
	this.getGroup().x = this.point.getX();
	this.getGroup().y = this.point.getY()+4;
};

cCharacter.prototype.action = function() {
	let returnValue = false;
	switch (this.status) {
		case CHARACTER_STATUS_NORMAL:
			returnValue = this.actionNormal();
			break;
		case CHARACTER_STATUS_HANGING:
			returnValue = this.actionHanging();
			break;
	}

	return returnValue;
};

cCharacter.prototype.actionNormal = function() {
	let newPosition = false;

	// Z押しながらでブロック移動になる
	if (keyInput.isZ()) {
		const point = new cPoint(this.position.getX(), this.position.getY(), this.position.getZ());
		const xPlusPoint = new cPoint(this.position.getX()+1, this.position.getY(), this.position.getZ());
		const xMinusPoint = new cPoint(this.position.getX()-1, this.position.getY(), this.position.getZ());
		const zPlusPoint = new cPoint(this.position.getX(), this.position.getY(), this.position.getZ()+1);
		const zMinusPoint = new cPoint(this.position.getX(), this.position.getY(), this.position.getZ()-1);

		// ブロック移動はキャラの向きで処理が変わる
		// 向きと同じ方向は押す、逆の方向は引く
		switch (this.direction) {
			case D_TOP:
				if (map.checkBlock(zPlusPoint)) {
					if (keyInput.isUp()) {
						if (map.checkBlockPush(zPlusPoint, D_TOP)) {
							map.setMoveCubeInfo(zPlusPoint, D_TOP);
							return MAP_TASK_CUBE_MOVE;
						}
					} else
					if (keyInput.isDown()) {
						if (map.checkBlockPull(point, D_DOWN)) {
							map.setMoveCubeInfo(zPlusPoint, D_DOWN);
							return MAP_TASK_CUBE_MOVE;
						}
					}
				}
				break;

			case D_DOWN:
				if (map.checkBlock(zMinusPoint)) {
					if (keyInput.isDown()) {
						if (map.checkBlockPush(zMinusPoint, D_DOWN)) {
							map.setMoveCubeInfo(zMinusPoint, D_DOWN);
							return MAP_TASK_CUBE_MOVE;
						}
					} else
					if (keyInput.isUp()) {
						if (map.checkBlockPull(point, D_TOP)) {
							map.setMoveCubeInfo(zMinusPoint, D_TOP);
							return MAP_TASK_CUBE_MOVE;
						}
					}
				}
				break;

			case D_LEFT:
				if (map.checkBlock(xMinusPoint)) {
					if (keyInput.isLeft()) {
						if (map.checkBlockPush(xMinusPoint, D_LEFT)) {
							map.setMoveCubeInfo(xMinusPoint, D_LEFT);
							return MAP_TASK_CUBE_MOVE;
						}
					} else
					if (keyInput.isRight()) {
						if (map.checkBlockPull(point, D_RIGHT)) {
							map.setMoveCubeInfo(xMinusPoint, D_RIGHT);
							return MAP_TASK_CUBE_MOVE;
						}
					}
				}
				break;

			case D_RIGHT:
				if (map.checkBlock(xPlusPoint)) {
					if (keyInput.isRight()) {
						if (map.checkBlockPush(xPlusPoint, D_RIGHT)) {
							map.setMoveCubeInfo(xPlusPoint, D_RIGHT);
							return MAP_TASK_CUBE_MOVE;
						}
					} else
					if (keyInput.isLeft()) {
						if (map.checkBlockPull(point, D_LEFT)) {
							map.setMoveCubeInfo(xPlusPoint, D_LEFT);
							return MAP_TASK_CUBE_MOVE;
						}
					}
				}
				break;
		}
	} else {
		// キャラクター移動
		if (keyInput.isUp()) {
			this.changeDirection(D_TOP);
			// X キー押しながらで向きだけ変わる
			if (!keyInput.isX()) {
				newPosition = map.checkMove(this.position, new cPoint(this.position.getX(), this.position.getY(), this.position.getZ()+1));
			}
		} else
		if (keyInput.isRight()) {
			this.changeDirection(D_RIGHT);
			if (!keyInput.isX()) {
				newPosition = map.checkMove(this.position, new cPoint(this.position.getX()+1, this.position.getY(), this.position.getZ()));
			}
		} else
		if (keyInput.isDown()) {
			this.changeDirection(D_DOWN);
			if (!keyInput.isX()) {
				newPosition = map.checkMove(this.position, new cPoint(this.position.getX(), this.position.getY(), this.position.getZ()-1));
			}
		} else
		if (keyInput.isLeft()) {
			this.changeDirection(D_LEFT);
			if (!keyInput.isX()) {
				newPosition = map.checkMove(this.position, new cPoint(this.position.getX()-1, this.position.getY(), this.position.getZ()));
			}
		}
	}

	if (newPosition) {
		this.setPosition(newPosition);
	}

	return MAP_TASK_INPUT_WAIT;
};

cCharacter.prototype.setPosition = function(position) {
	this.position = position;
	this.update();
};

cCharacter.prototype.actionHanging = function() {
	return MAP_TASK_INPUT_WAIT;
};

cCharacter.prototype.draw = function() {

};

cCharacter.prototype.getPosition = function() {
	return this.position;
};

cCharacter.prototype.update = function() {
	this.point = positionToPoint(this.position);
	this.getGroup().x = this.point.getX();
	this.getGroup().y = this.point.getY()+4;

	map.updateCharacterZindex();
};

cCharacter.prototype.getDirection = function() {
	return this.direction;
};

cCharacter.prototype.changeDirection = function(direction) {
	this.direction = direction;
	this.sprite.frame = this.direction;
};

cCharacter.prototype.moveRight = function() {
	this.getGroup().x += 2;
	++this.getGroup().y;
};

cCharacter.prototype.moveLeft = function() {
	this.getGroup().x -= 2;
	--this.getGroup().y;
};

cCharacter.prototype.moveDown = function() {
	this.getGroup().x -= 2;
	this.getGroup().y += 1;
};

cCharacter.prototype.moveTop = function() {
	this.getGroup().x += 2;
	this.getGroup().y -= 1;
};

cCharacter.prototype.moveFall = function() {
	this.getGroup().y += 2;
};