var inherits = function(childCtor, parentCtor) {
	Object.setPrototypeOf(childCtor.prototype, parentCtor.prototype);
};